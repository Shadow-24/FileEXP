#pragma once
#include "ArbolB.h"
#include <msclr\marshal_cppstd.h>
#include "ArbolPruebah.h"
//..
namespace TF {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::IO;
	using namespace msclr::interop;

	/// <summary>
	/// Resumen de MyForm
	/// </summary>
	long long tamano[1000];
	std::string nombre[1000];
	std::string extension[1000];
	std::string fecha[1000];
	long long arrAux[1000];
	int n = 0;
	int t = 0;
	int ex = 0;
	int f = 0;
	public ref class MyForm : public System::Windows::Forms::Form
	{
		//btree tree
		btree *tree = new btree();
		
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::ListBox^  listBox2;
	private: System::Windows::Forms::ListBox^  listBox3;
	private: System::Windows::Forms::ListBox^  listBox4;
	private: System::Windows::Forms::Button^  btnLimpiar;
			 System::String ^ruta = System::String::Empty;
	public:
	
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
			
		}
		
	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n usando.
		/// </summary>
		
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  button1;
	protected:
	private: System::Windows::Forms::ListBox^  listBox1;
	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::Button^  btnName;
	private: System::Windows::Forms::Button^  btnSize;
	private: System::Windows::Forms::Button^  btnExt;
	private: System::Windows::Forms::Button^  btnDateC;
	private: System::Windows::Forms::Button^  btnMayor;
	private: System::Windows::Forms::Button^  btnMenor;
	private: System::Windows::Forms::TextBox^  txtvalor;
	private: System::Windows::Forms::TextBox^  textBox2;




	private: System::Windows::Forms::TextBox^  textBox3;

	private: System::Windows::Forms::Button^  btnEC;
	private: System::Windows::Forms::Button^  btnTC;
	private: System::Windows::Forms::Button^  btnContiene;
	private: System::Windows::Forms::TextBox^  textBox4;
	private: System::Windows::Forms::TextBox^  txtCreacion;

	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Button^  btnCrear;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  txtNumbre;
	private: System::Windows::Forms::Button^  txtEliminar;




		
	private:
		/// <summary>
		/// Variable del dise�ador necesaria.
		/// </summary>
		System::ComponentModel::Container ^components;
		
#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido de este m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->listBox1 = (gcnew System::Windows::Forms::ListBox());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->btnName = (gcnew System::Windows::Forms::Button());
			this->btnSize = (gcnew System::Windows::Forms::Button());
			this->btnExt = (gcnew System::Windows::Forms::Button());
			this->btnDateC = (gcnew System::Windows::Forms::Button());
			this->btnMayor = (gcnew System::Windows::Forms::Button());
			this->btnMenor = (gcnew System::Windows::Forms::Button());
			this->txtvalor = (gcnew System::Windows::Forms::TextBox());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->textBox3 = (gcnew System::Windows::Forms::TextBox());
			this->btnEC = (gcnew System::Windows::Forms::Button());
			this->btnTC = (gcnew System::Windows::Forms::Button());
			this->btnContiene = (gcnew System::Windows::Forms::Button());
			this->textBox4 = (gcnew System::Windows::Forms::TextBox());
			this->txtCreacion = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->btnCrear = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->txtNumbre = (gcnew System::Windows::Forms::TextBox());
			this->txtEliminar = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->listBox2 = (gcnew System::Windows::Forms::ListBox());
			this->listBox3 = (gcnew System::Windows::Forms::ListBox());
			this->listBox4 = (gcnew System::Windows::Forms::ListBox());
			this->btnLimpiar = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(12, 13);
			this->button1->Margin = System::Windows::Forms::Padding(4);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(1078, 119);
			this->button1->TabIndex = 0;
			this->button1->Text = L"Seleccionar ruta de Directorios";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// listBox1
			// 
			this->listBox1->FormattingEnabled = true;
			this->listBox1->ItemHeight = 16;
			this->listBox1->Location = System::Drawing::Point(15, 346);
			this->listBox1->Margin = System::Windows::Forms::Padding(4);
			this->listBox1->Name = L"listBox1";
			this->listBox1->Size = System::Drawing::Size(268, 292);
			this->listBox1->TabIndex = 1;
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(14, 140);
			this->textBox1->Margin = System::Windows::Forms::Padding(4);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(962, 22);
			this->textBox1->TabIndex = 2;
			// 
			// btnName
			// 
			this->btnName->Location = System::Drawing::Point(27, 172);
			this->btnName->Name = L"btnName";
			this->btnName->Size = System::Drawing::Size(173, 36);
			this->btnName->TabIndex = 3;
			this->btnName->Text = L"Nombre";
			this->btnName->UseVisualStyleBackColor = true;
			this->btnName->Click += gcnew System::EventHandler(this, &MyForm::btnName_Click);
			// 
			// btnSize
			// 
			this->btnSize->Location = System::Drawing::Point(313, 172);
			this->btnSize->Name = L"btnSize";
			this->btnSize->Size = System::Drawing::Size(173, 36);
			this->btnSize->TabIndex = 4;
			this->btnSize->Text = L"Tama�o";
			this->btnSize->UseVisualStyleBackColor = true;
			this->btnSize->Click += gcnew System::EventHandler(this, &MyForm::btnSize_Click);
			// 
			// btnExt
			// 
			this->btnExt->Location = System::Drawing::Point(895, 169);
			this->btnExt->Name = L"btnExt";
			this->btnExt->Size = System::Drawing::Size(173, 35);
			this->btnExt->TabIndex = 5;
			this->btnExt->Text = L"Extensi�n";
			this->btnExt->UseVisualStyleBackColor = true;
			this->btnExt->Click += gcnew System::EventHandler(this, &MyForm::btnExt_Click);
			// 
			// btnDateC
			// 
			this->btnDateC->Location = System::Drawing::Point(652, 169);
			this->btnDateC->Name = L"btnDateC";
			this->btnDateC->Size = System::Drawing::Size(173, 35);
			this->btnDateC->TabIndex = 6;
			this->btnDateC->Text = L"Fecha";
			this->btnDateC->UseVisualStyleBackColor = true;
			this->btnDateC->Click += gcnew System::EventHandler(this, &MyForm::btnDateC_Click);
			// 
			// btnMayor
			// 
			this->btnMayor->Location = System::Drawing::Point(313, 215);
			this->btnMayor->Name = L"btnMayor";
			this->btnMayor->Size = System::Drawing::Size(173, 26);
			this->btnMayor->TabIndex = 7;
			this->btnMayor->Text = L"Mayor a Menor";
			this->btnMayor->UseVisualStyleBackColor = true;
			this->btnMayor->Click += gcnew System::EventHandler(this, &MyForm::btnMayor_Click);
			// 
			// btnMenor
			// 
			this->btnMenor->Location = System::Drawing::Point(313, 267);
			this->btnMenor->Name = L"btnMenor";
			this->btnMenor->Size = System::Drawing::Size(173, 28);
			this->btnMenor->TabIndex = 8;
			this->btnMenor->Text = L"Menor a Mayor";
			this->btnMenor->UseVisualStyleBackColor = true;
			this->btnMenor->Click += gcnew System::EventHandler(this, &MyForm::btnMenor_Click);
			// 
			// txtvalor
			// 
			this->txtvalor->Location = System::Drawing::Point(492, 318);
			this->txtvalor->Name = L"txtvalor";
			this->txtvalor->Size = System::Drawing::Size(98, 22);
			this->txtvalor->TabIndex = 9;
			// 
			// textBox2
			// 
			this->textBox2->Location = System::Drawing::Point(154, 220);
			this->textBox2->Name = L"textBox2";
			this->textBox2->Size = System::Drawing::Size(45, 22);
			this->textBox2->TabIndex = 10;
			// 
			// textBox3
			// 
			this->textBox3->Location = System::Drawing::Point(155, 271);
			this->textBox3->Name = L"textBox3";
			this->textBox3->Size = System::Drawing::Size(45, 22);
			this->textBox3->TabIndex = 13;
			// 
			// btnEC
			// 
			this->btnEC->Location = System::Drawing::Point(26, 216);
			this->btnEC->Name = L"btnEC";
			this->btnEC->Size = System::Drawing::Size(122, 30);
			this->btnEC->TabIndex = 15;
			this->btnEC->Text = L"Empieza con:";
			this->btnEC->UseVisualStyleBackColor = true;
			this->btnEC->Click += gcnew System::EventHandler(this, &MyForm::btnEC_Click);
			// 
			// btnTC
			// 
			this->btnTC->Location = System::Drawing::Point(28, 268);
			this->btnTC->Name = L"btnTC";
			this->btnTC->Size = System::Drawing::Size(121, 29);
			this->btnTC->TabIndex = 16;
			this->btnTC->Text = L"Termina con:";
			this->btnTC->UseVisualStyleBackColor = true;
			this->btnTC->Click += gcnew System::EventHandler(this, &MyForm::btnTC_Click);
			// 
			// btnContiene
			// 
			this->btnContiene->Location = System::Drawing::Point(27, 320);
			this->btnContiene->Name = L"btnContiene";
			this->btnContiene->Size = System::Drawing::Size(121, 23);
			this->btnContiene->TabIndex = 17;
			this->btnContiene->Text = L"Contiene";
			this->btnContiene->UseVisualStyleBackColor = true;
			this->btnContiene->Click += gcnew System::EventHandler(this, &MyForm::btnContiene_Click);
			// 
			// textBox4
			// 
			this->textBox4->Location = System::Drawing::Point(155, 320);
			this->textBox4->Name = L"textBox4";
			this->textBox4->Size = System::Drawing::Size(45, 22);
			this->textBox4->TabIndex = 18;
			// 
			// txtCreacion
			// 
			this->txtCreacion->Location = System::Drawing::Point(733, 234);
			this->txtCreacion->Name = L"txtCreacion";
			this->txtCreacion->Size = System::Drawing::Size(258, 22);
			this->txtCreacion->TabIndex = 19;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(730, 214);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(229, 17);
			this->label1->TabIndex = 20;
			this->label1->Text = L"Ruta del archivo a crear o eliminar:";
			// 
			// btnCrear
			// 
			this->btnCrear->Location = System::Drawing::Point(998, 231);
			this->btnCrear->Name = L"btnCrear";
			this->btnCrear->Size = System::Drawing::Size(95, 34);
			this->btnCrear->TabIndex = 21;
			this->btnCrear->Text = L"Crear";
			this->btnCrear->UseVisualStyleBackColor = true;
			this->btnCrear->Click += gcnew System::EventHandler(this, &MyForm::btnCrear_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(730, 254);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(261, 17);
			this->label2->TabIndex = 22;
			this->label2->Text = L"Nombre de archivo(agregar \'\\\\\' al inicio):";
			// 
			// txtNumbre
			// 
			this->txtNumbre->Location = System::Drawing::Point(733, 274);
			this->txtNumbre->Name = L"txtNumbre";
			this->txtNumbre->Size = System::Drawing::Size(258, 22);
			this->txtNumbre->TabIndex = 23;
			// 
			// txtEliminar
			// 
			this->txtEliminar->Location = System::Drawing::Point(997, 271);
			this->txtEliminar->Name = L"txtEliminar";
			this->txtEliminar->Size = System::Drawing::Size(96, 29);
			this->txtEliminar->TabIndex = 24;
			this->txtEliminar->Text = L"Eliminar";
			this->txtEliminar->UseVisualStyleBackColor = true;
			this->txtEliminar->Click += gcnew System::EventHandler(this, &MyForm::txtEliminar_Click);
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(313, 318);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(173, 23);
			this->button2->TabIndex = 25;
			this->button2->Text = L"Buscar Valor";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &MyForm::button2_Click);
			// 
			// listBox2
			// 
			this->listBox2->FormattingEnabled = true;
			this->listBox2->ItemHeight = 16;
			this->listBox2->Location = System::Drawing::Point(290, 347);
			this->listBox2->Name = L"listBox2";
			this->listBox2->Size = System::Drawing::Size(225, 292);
			this->listBox2->TabIndex = 26;
			// 
			// listBox3
			// 
			this->listBox3->FormattingEnabled = true;
			this->listBox3->ItemHeight = 16;
			this->listBox3->Location = System::Drawing::Point(620, 346);
			this->listBox3->Name = L"listBox3";
			this->listBox3->Size = System::Drawing::Size(225, 292);
			this->listBox3->TabIndex = 27;
			// 
			// listBox4
			// 
			this->listBox4->FormattingEnabled = true;
			this->listBox4->ItemHeight = 16;
			this->listBox4->Location = System::Drawing::Point(870, 346);
			this->listBox4->Name = L"listBox4";
			this->listBox4->Size = System::Drawing::Size(225, 292);
			this->listBox4->TabIndex = 28;
			// 
			// btnLimpiar
			// 
			this->btnLimpiar->Location = System::Drawing::Point(984, 140);
			this->btnLimpiar->Name = L"btnLimpiar";
			this->btnLimpiar->Size = System::Drawing::Size(106, 23);
			this->btnLimpiar->TabIndex = 29;
			this->btnLimpiar->Text = L"Limpiar";
			this->btnLimpiar->UseVisualStyleBackColor = true;
			this->btnLimpiar->Click += gcnew System::EventHandler(this, &MyForm::btnLimpiar_Click);
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(1107, 641);
			this->Controls->Add(this->btnLimpiar);
			this->Controls->Add(this->listBox4);
			this->Controls->Add(this->listBox3);
			this->Controls->Add(this->listBox2);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->txtEliminar);
			this->Controls->Add(this->txtNumbre);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->btnCrear);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->txtCreacion);
			this->Controls->Add(this->textBox4);
			this->Controls->Add(this->btnContiene);
			this->Controls->Add(this->btnTC);
			this->Controls->Add(this->btnEC);
			this->Controls->Add(this->textBox3);
			this->Controls->Add(this->textBox2);
			this->Controls->Add(this->txtvalor);
			this->Controls->Add(this->btnMenor);
			this->Controls->Add(this->btnMayor);
			this->Controls->Add(this->btnDateC);
			this->Controls->Add(this->btnExt);
			this->Controls->Add(this->btnSize);
			this->Controls->Add(this->btnName);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->listBox1);
			this->Controls->Add(this->button1);
			this->Margin = System::Windows::Forms::Padding(4);
			this->Name = L"MyForm";
			this->Text = L"MyForm";
			this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
		//Console::Clear();
		arrAux[1000] = NULL;
		tamano[1000] = NULL;
		nombre[1000] = "";
		extension[1000] = "";
		fecha[1000] = "";
		n = 0;
		t = 0;
		ex = 0;
		f = 0;
		
		System::String^ folderName = System::String::Empty;
		FolderBrowserDialog ^fbd = gcnew System::Windows::Forms::FolderBrowserDialog;
		System::Windows::Forms::DialogResult result = fbd->ShowDialog();
		if (result == System::Windows::Forms::DialogResult::OK)
		{
			folderName = fbd->SelectedPath;
		}
		textBox1->Text = folderName;
		if (folderName->Trim() != System::String::Empty)
		{
			DirectoryInfo ^di = gcnew DirectoryInfo(folderName);
			for each(FileInfo^ item  in  di->GetFiles())
			{
				tamano[t++] = item->Length;
				char cStr[1000] = { 0 };
				char cStr2[1000] = { 0 };
				char cStr3[1000] = { 0 };
				String ^clrString = item->Extension;
				String^ clrString2 = item->Name;
				String^ clrString3 = item->CreationTime.ToString();
				if (clrString->Length < sizeof(cStr))
					sprintf(cStr, "%s", clrString);
				std::string stlString(cStr);
				extension[ex++] = stlString;
				if (clrString2->Length < sizeof(cStr2))
					sprintf(cStr2, "%s", clrString2);
				std::string stlString2(cStr2);
				nombre[n++] = stlString2;
				if (clrString3->Length < sizeof(cStr3))
					sprintf(cStr3, "%s", clrString3);
				std::string stlString3(cStr3);
				fecha[f++]=stlString3;
				}
			listBox1->Items->Clear();
			listBox2->Items->Clear();
			listBox3->Items->Clear();
			listBox4->Items->Clear();
			for (int i = 0; i < t; i++) {
				arrAux[i] = tamano[i];
				listBox1->Items->Add(gcnew String(nombre[i].c_str()));
				listBox2->Items->Add(tamano[i] + " KB");
				listBox3->Items->Add(gcnew String(fecha[i].c_str()));
				listBox4->Items->Add(gcnew String(extension[i].c_str()));
			}
		}
	}
	

private: System::Void MyForm_Load(System::Object^  sender, System::EventArgs^  e) {
	
}
private: System::Void btnName_Click(System::Object^  sender, System::EventArgs^  e) {
		//Console::Clear();
		listBox1->Items->Clear();
		sort(nombre, n);
	
	for (int i = 0; i < n; i++) {
		listBox1->Items->Add(gcnew String(nombre[i].c_str()));
	}
		}
private: System::Void btnExt_Click(System::Object^  sender, System::EventArgs^  e) {
	//Console::Clear();
	listBox4->Items->Clear();
	sort(extension, ex);
	for (int i = 0; i < ex; i++) {
		listBox4->Items->Add(gcnew String(extension[i].data()));
	}
}
private: System::Void btnSize_Click(System::Object^  sender, System::EventArgs^  e) {
		//Console::Clear();
		listBox2->Items->Clear();
		
		for (int i = 0; i < t; i++) {
		
			tree->insert(tamano[i]);
		}
		tree->inorder_print();
		
	/*	cout << "Ingrese un valor a buscar: "; cin >> valor; cout << endl;
		 tree->search(valor);*/
	
	 for (int i = 0; i < t; i++) {
		 listBox2->Items->Add(arrAux[i] + " KB");
			 }
		 
	 }
			
private: System::Void btnDateC_Click(System::Object^  sender, System::EventArgs^  e) {
	//Console::Clear();
	listBox3->Items->Clear();
	sort(fecha, f);
	for (int i = 0; i < f; i++) {
		listBox3->Items->Add(gcnew String(fecha[i].c_str()));
	}
}

private: System::Void btnMayor_Click(System::Object^  sender, System::EventArgs^  e) {
	//Console::Clear();
	listBox2->Items->Clear();
	heapSortD(tamano, t);
	for (int i = 0; i < t; i++) {
		//cout << tamano[i] << endl;
		listBox2->Items->Add( tamano[i] + " KB");
	}

}

private: System::Void btnMenor_Click(System::Object^  sender, System::EventArgs^  e) {
	//Console::Clear();
	listBox2->Items->Clear();
	
	heapSortA(tamano, t);
	for (int i = 0; i < t; i++) {
		//cout << tamano[i] << endl;
		listBox2->Items->Add(tamano[i] + " KB");
	}
}
//private: System::Void txtvalor_Enter(System::Object^  sender, System::EventArgs^  e) {
//	long long valor;
//	txtvalor->Text;
//	tree->search(valor);
//}

private: System::Void btnEC_Click(System::Object^  sender, System::EventArgs^  e) {
	//Console::Clear();
	listBox1->Items->Clear();
	String^ letra = textBox2->Text;
	if (letra == "") {
		//cout << "";
	}
	else
	{
		for (int i = 0; i < n; i++) {
			if (letra[0] == nombre[i].front()) {
				//cout << nombre[i] << endl;
				listBox1->Items->Add(gcnew String(nombre[i].c_str()));
			}
		}
	}
	textBox2->Text = "";
}
private: System::Void btnTC_Click(System::Object^  sender, System::EventArgs^  e) {
	//Console::Clear();
	listBox1->Items->Clear();
	String^ letra = textBox3->Text;
	char a;
	if (letra == "") {
		//cout << "";
	}
	else {
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < nombre[i].length(); j++) {
				if (nombre[i].at(j) == '.') {
					a = nombre[i].at(j - 1);
					if (letra[0] == a) {
						//cout << nombre[i] << endl;
						listBox1->Items->Add(gcnew String(nombre[i].c_str()));
					}

				}
			}

		}
	}
	textBox3->Text = "";
	
}
private: System::Void btnContiene_Click(System::Object^  sender, System::EventArgs^  e) {
	//Console::Clear();
	listBox1->Items->Clear();
	String^ letra = textBox4->Text;
	char a;
	int con;
	int nt;
	int d;
	int k;
	int i;
	if (letra == "") {
		//cout << "";
	}
	else {
		for ( i = 0; i < n; i++) {
			for (int j = 0; j < nombre[i].length(); j++) {
				if (nombre[i].at(j) == '.') {
					con = j;
				}
			}
			d = nombre[i].length() - con;
			nt = nombre[i].length() - d;
			
				for (k = 0; k < nt; k++) {
					if (nombre[i].at(k) == letra[0]) {
						//cout << nombre[i] << endl;
						listBox1->Items->Add(gcnew String(nombre[i].c_str()));
						break;
					}
				}
			

		}
		
	}
	textBox4->Text = "";
}

private: System::Void btnCrear_Click(System::Object^  sender, System::EventArgs^  e) {
	if (txtNumbre->Text != "") {
		ruta = txtNumbre->Text->ToString();
		StreamWriter ^sw = gcnew StreamWriter(txtCreacion->Text + ruta);
		sw->Close();
	}
}
private: System::Void txtEliminar_Click(System::Object^  sender, System::EventArgs^  e) {
	if (txtCreacion->Text != "") {
		ruta = txtNumbre->Text->ToString();
		String^elim = txtCreacion->Text->ToString()+ruta;
		File::Delete(elim);
	}
}

private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
	listBox2->Items->Clear();
	txtvalor->Clear();
	for (int i = 0; i < t; i++) {
		if (tamano[i].ToString() == txtvalor->Text) {
			listBox2->Items->Add(tamano[i]+ " KB");
		}
	}
}
private: System::Void btnLimpiar_Click(System::Object^  sender, System::EventArgs^  e) {
	listBox1->Items->Clear();
	listBox2->Items->Clear();
	listBox3->Items->Clear();
	listBox4->Items->Clear();
	textBox1->Clear();
}
};
}
