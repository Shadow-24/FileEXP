#pragma once
#include<iostream>
#include <string>
#include <functional>
#include <fstream>
using namespace std;


void heapifyD(long long arr[], int n, int i)
{
	int smallest = i; // Initialize smalles as root 
	int l = 2 * i + 1; // left = 2*i + 1 
	int r = 2 * i + 2; // right = 2i + 2 

					   // If left child is smaller than root 
	if (l < n && arr[l] < arr[smallest])
		smallest = l;

	// If right child is smaller than smallest so far 
	if (r < n && arr[r] < arr[smallest])
		smallest = r;

	// If smallest is not root 
	if (smallest != i) {
		swap(arr[i], arr[smallest]);

		// Recursively heapify the affected sub-tree 
		heapifyD(arr, n, smallest);
	}
}

// main function to do heap sort 
void heapSortD(long long arr[], int n)
{
	// Build heap (rearrange array) 
	for (int i = n / 2 - 1; i >= 0; i--)
		heapifyD(arr, n, i);

	// One by one extract an element from heap 
	for (int i = n - 1; i >= 0; i--) {
		// Move current root to end 
		swap(arr[0], arr[i]);

		// call max heapify on the reduced heap 
		heapifyD(arr, i, 0);
	}
}

// A utility function to print array of size n * /

void heapifyA(long long arr[], int n, int i)
{
	int largest = i; // Initialize largest as root 
	int l = 2 * i + 1; // left = 2*i + 1 
	int r = 2 * i + 2; // right = 2*i + 2 

					   // If left child is larger than root 
	if (l < n && arr[l] > arr[largest])
		largest = l;

	// If right child is larger than largest so far 
	if (r < n && arr[r] > arr[largest])
		largest = r;

	// If largest is not root 
	if (largest != i)
	{
		swap(arr[i], arr[largest]);

		// Recursively heapify the affected sub-tree 
		heapifyA(arr, n, largest);
	}
}

// main function to do heap sort 
void heapSortA(long long arr[], int n)
{
	// Build heap (rearrange array) 
	for (int i = n / 2 - 1; i >= 0; i--)
		heapifyA(arr, n, i);

	// One by one extract an element from heap 
	for (int i = n - 1; i >= 0; i--)
	{
		// Move current root to end 
		swap(arr[0], arr[i]);

		// call max heapify on the reduced heap 
		heapifyA(arr, i, 0);
	}
}

/* A utility function to print array of size n */
void printArray(long long arr[], int n)
{
	for (int i = 0; i<n; ++i)
		cout << arr[i] << " ";
	cout << "\n";
}

int x = -1;

// Predefining the heap array 
string heap[1000];
// Defining formation of the heap 
void heapForm(string k)
{
	x++;

	heap[x] = k;

	int child = x;

	string tmp;

	int index = x / 2;

	// Iterative heapiFy 
	while (index >= 0) {

		// Just swapping if the element 
		// is smaller than already 
		// stored element 
		if (heap[index] > heap[child]) {

			// Swapping the current index 
			// with its child 
			tmp = heap[index];
			heap[index] = heap[child];
			heap[child] = tmp;
			child = index;

			// Moving upward in the 
			// heap 
			index = index / 2;
		}
		else {
			break;
		}
	}
}

// Defining heap sort 
void heapSort()
{
	int left1, right1;

	while (x >= 0) {
		string k;
		k = heap[0];

		// Taking output of 
		// the minimum element 
		//cout << k << endl;

		// Set first element 
		// as a last one 
		heap[0] = heap[x];

		// Decrement of the 
		// size of the string 
		x = x - 1;

		string tmp;

		int index = 0;

		int length = x;

		// Initilizing the left 
		// and right index 
		left1 = 1;

		right1 = left1 + 1;

		while (left1 <= length) {

			// Process of heap sort 
			// If root element is 
			// minimum than its both 
			// of the child then break 
			if (heap[index] <= heap[left1]
				&& heap[index] <= heap[right1]) {
				break;
			}

			// Otherwise checking that 
			// the child which one is 
			// smaller, swap them with 
			// parent element 
			else {

				// Swapping 
				if (heap[left1] < heap[right1]) {
					tmp = heap[index];
					heap[index] = heap[left1];
					heap[left1] = tmp;
					index = left1;
				}

				else {
					tmp = heap[index];
					heap[index] = heap[right1];
					heap[right1] = tmp;
					index = right1;
				}
			}

			// Changing the left index 
			// and right index 
			left1 = 2 * left1;
			right1 = left1 + 1;
		}
	}
}

// Utility function 
void sort(string k[], int n)
{

	// To heapiFy 
	for (int i = 0; i < n; i++) {
		heapForm(k[i]);
	}

	// Calling heap sort function 
	heapSort();
}